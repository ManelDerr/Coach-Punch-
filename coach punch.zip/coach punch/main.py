import pygame
import os
import time 
import random
pygame.font.init()



WIDTH, HEIGHT = 650, 600
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Coach Punch")



#images
B1 = pygame.image.load(os.path.join("photos", "B1.png"))
B2 = pygame.image.load(os.path.join("photos", "B2.png"))
M = pygame.image.load(os.path.join("photos", "M.png"))

#coach 
B = pygame.image.load(os.path.join("photos", "B.png"))

#punch
P = pygame.image.load(os.path.join("photos", "p.png"))

#Background
BG = pygame.transform.scale(pygame.image.load(os.path.join("photos", "bg.png")), (WIDTH, HEIGHT))



p1= None
p2= None
p3= None



class Punch:
	def __init__(self, x, y, img):
		self.x = x
		self.y = y
		self.img = img
		self.mask = pygame.mask.from_surface(self.img)

	def draw(self, window):
		window.blit(self.img, (self.x, self.y))

	def move(self, vel):
		self.y += vel

	def off_screen(self, height):
		return not (self.y <= height and self.y >= 0)

	def collision(self, obj): 
		return collide(self, obj)           	



class A:
	COOLDOWN = 30

	def __init__(self, x, y, health=100):   
		self.x = x
		self.y = y
		self.health = health
		self.a_img = None
		self.p_img = None
		self.punches = []
		self.cool_down_counter = 0 

	def draw(self, window):                 
		window.blit(self.a_img, (self.x, self.y))
		for p in self.punches:
			p.draw(window)

	def move_punches(self, vel, obj):
		self.cooldown()
		for p in self.punches:
			p.move(vel)
			if p.off_screen(HEIGHT):
				self.punches.remove(p)
			elif p.collision(obj):
				obj.health -= 10
				self.punches.remove(p)	

	def cooldown(self):
		if self.cool_down_counter >= self.COOLDOWN:
			self.cool_down_counter = 0
		elif self.cool_down_counter > 0:
			self.cool_down_counter += 1	

	def shoot(self):
		if self.cool_down_counter == 0:
			p = Punch(self.x, self.y, self.p_img)
			self.punches.append(p)
			self.cool_down_counter = 1 

	def get_width(self):
		return self.a_img.get_width()	
		
	def get_height(self):
		return self.a_img.get_height()    	 




class Coach(A): 
	def __init__(self, x, y, health=100):
		super().__init__(x, y, health)
		self.a_img = B
		self.p_img = P
		self.mask = pygame.mask.from_surface(self.a_img)
		self.max_health = health

	def move_punches(self, vel, objs):
		self.cooldown()
		for p in self.punches:
			p.move(vel)
			if p.off_screen(HEIGHT):
				self.punches.remove(p)
			else: 
				for obj in objs:
					if p.collision(obj):
						objs.remove(obj)
						if p in self.punches:
						   self.punches.remove(p)		




class Player(A):
	B_MAP = {
				"B1": (B1, p1),
				"B2": (B2, p2),
				"M": (M,p3)
				}

	def __init__(self, x, y, b, health=100):
		super().__init__(x, y, health)
		self.a_img, self.p_img = self.B_MAP[b]
		self.mask = pygame.mask.from_surface(self.a_img)

	def move(self, vel):
		self.y  += vel

def collide (obj1, obj2):
	offset_x = obj2.x - obj1.x #décalage
	offset_y = obj2.y - obj1.y
	return obj1.mask.overlap(obj2.mask, (offset_x, offset_y)) != None 



def main():
	run = True
	FPS = 90 #frames per second: the lower this number the slower the game is gonna run
	level = "EL WAHCH"
	lives = "Eternal"
	main_font = pygame.font.SysFont("comicsans", 50)
	lost_font = pygame.font.SysFont("comicsans", 60)

	players = []
	wave_length = 5  
	player_vel = 1

	coach_vel = 5
	punch_vel = 20

	coach = Coach(260, 500) 

	clock = pygame.time.Clock()


	def redraw_window():
			WIN.blit(BG, (0,0)) 
			
			lives_label = main_font.render(f"Lives: {lives}", 1, (255, 255, 255))
			level_label = main_font.render(f"Level: {level}", 1, (255, 255, 255))


			WIN.blit(lives_label, (10,10)) #10px down, 10px right
			WIN.blit(level_label, (WIDTH - level_label.get_width() - 10, 10))

			for player in players:
				player.draw(WIN)

			coach.draw(WIN) 

			pygame.display.update() 



	while run:
		clock.tick(FPS)
		redraw_window() 

		if len(players) == 0:
			wave_length += 5
			for i in range(wave_length):
				player = Player(random.randrange(50, WIDTH - 100), random.randrange(-1500, -100), random.choice(["B1", "B2", "M"]))
				players.append(player)

		for event in pygame.event.get():
			if event.type == pygame.QUIT:  
				run = False



		keys = pygame.key.get_pressed()
		if keys[pygame.K_LEFT] and coach.x - coach_vel > 0: #left
			coach.x -= coach_vel
		if keys[pygame.K_RIGHT] and coach.x + coach_vel + coach.get_width() < WIDTH: #right
			coach.x += coach_vel
		if keys[pygame.K_UP] and coach.y - coach_vel > 0: #up
			coach.y -= coach_vel
		if keys[pygame.K_DOWN] and coach.y + coach_vel + coach.get_height() < HEIGHT: #down
			coach.y += coach_vel	
		if keys[pygame.K_SPACE]:
			coach.shoot()	
		
		for player in players[:]:
			player.move(player_vel)
			if player.y + player.get_height() > HEIGHT:
				players.remove(player)

		coach.move_punches(-punch_vel, players)		
					
main()				